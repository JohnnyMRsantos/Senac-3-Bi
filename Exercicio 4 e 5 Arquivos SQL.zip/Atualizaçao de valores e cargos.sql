UPDATE funcionarios Set cargo = 'Coordenador' where id = 6 ;
SELECT * FROM funcionarios;