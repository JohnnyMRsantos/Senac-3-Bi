DELETE FROM funcionarios WHERE id =5
