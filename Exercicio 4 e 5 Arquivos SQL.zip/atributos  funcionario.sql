CREATE TABLE funcionarios(
  ID int(3)UNIQUE,
  Nome varchar(30)NOT NULL,
  Salario int(15)NOT NULL,
  cargo varchar(20) NOT NULL
  );