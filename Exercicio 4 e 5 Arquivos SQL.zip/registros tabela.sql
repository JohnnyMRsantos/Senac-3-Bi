INSERT INTO funcionarios(ID,Nome,Salario,cargo) VALUES( 9,'Jose',2300,'gerente');
SELECT * FROM funcionarios;